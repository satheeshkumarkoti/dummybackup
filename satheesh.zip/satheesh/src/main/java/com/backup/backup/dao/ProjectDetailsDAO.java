/**
 * 
 */
package com.conti.parma.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.conti.parma.model.ProjectDetailsInfo;
import com.conti.parma.model.ProjectDetailsMapper;
/**
 * @author uidp2090
 *
 */
@Repository
@Transactional
public class ProjectDetailsDAO extends JdbcDaoSupport {

	@Autowired
	public ProjectDetailsDAO(DataSource dataSource) {
			 this.setDataSource(dataSource);
	}

		
	public List<ProjectDetailsInfo> getProjectDetails() {
		// SELECT ID,RELEASE_NUMBER,PROJECT_NAME FROM PROJECTDETAILS
		String sql = ProjectDetailsMapper.SQL_QUERY_FOR_PROJ_DETAILS;

		Object[] params = new Object[] {};
		ProjectDetailsMapper mapper = new ProjectDetailsMapper();
		List<ProjectDetailsInfo> list = this.getJdbcTemplate().query(sql, params, mapper);

		return list;
	}	
	
	public ProjectDetailsInfo findProject(Long id) {
		// SELECT ID,RELEASE_NUMBER,PROJECT_NAME FROM PROJECTDETAILS
		// WHERE ID = ?
		String sql = ProjectDetailsMapper.SQL_QUERY_FOR_PROJ_DETAILS + " WHERE ID = ? ";

		Object[] params = new Object[] { id };
		ProjectDetailsMapper mapper = new ProjectDetailsMapper();
		try {
			ProjectDetailsInfo projectDetails = this.getJdbcTemplate().queryForObject(sql, params, mapper);
			return projectDetails;
		} catch (EmptyResultDataAccessException e) {
			return null;
		}
	}
		
}
