package com.conti.parma.model;

public class MasterDataInfo {

	// WP_TYPE_ID , ACTIVITY_NAME, TAILORING_ITEM, ROLE_ID, ROLE_NAME

	private Long wpTypeID;
	private String activityName;
	private String traloringItem;
	private String roleId;
	private String roldeName;

	public MasterDataInfo() {
		// TODO Auto-generated constructor stub
	}

	public MasterDataInfo(Long wpTypeID, String activityName, String traloringItem, String roleId, String roldeName) {
		this.wpTypeID = wpTypeID;
		this.activityName = activityName;
		this.traloringItem = traloringItem;
		this.roleId = roleId;
		this.roldeName = roldeName;

	}

	/**
	 * @return the wpTypeID
	 */
	public Long getWpTypeID() {
		return wpTypeID;
	}

	/**
	 * @param wpTypeID
	 *            the wpTypeID to set
	 */
	public void setWpTypeID(Long wpTypeID) {
		this.wpTypeID = wpTypeID;
	}

	/**
	 * @return the activityName
	 */
	public String getActivityName() {
		return activityName;
	}

	/**
	 * @param activityName
	 *            the activityName to set
	 */
	public void setActivityName(String activityName) {
		this.activityName = activityName;
	}

	/**
	 * @return the traloringItem
	 */
	public String getTraloringItem() {
		return traloringItem;
	}

	/**
	 * @param traloringItem
	 *            the traloringItem to set
	 */
	public void setTraloringItem(String traloringItem) {
		this.traloringItem = traloringItem;
	}

	/**
	 * @return the roleId
	 */
	public String getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId
	 *            the roleId to set
	 */
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	/**
	 * @return the roldeName
	 */
	public String getRoldeName() {
		return roldeName;
	}

	/**
	 * @param roldeName
	 *            the roldeName to set
	 */
	public void setRoldeName(String roldeName) {
		this.roldeName = roldeName;
	}

}
