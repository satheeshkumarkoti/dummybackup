package com.conti.parma.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class MasterDataMapper implements RowMapper<MasterDataInfo> {

	public MasterDataMapper() {
		// TODO Auto-generated constructor stub
		// WP_TYPE_ID , ACTIVITY_NAME, TAILORING_ITEM, ROLE_ID, ROLE_NAME
	}

	public static final String SQL_QUERY_FOR_MASTER_DATA = "SELECT MST_WP_ACTIVITY.WP_TYPE_ID, MST_WP_ACTIVITY.ACTIVITY_NAME, MST_WP_ACTIVITY.TAILORING_ITEM, MST_ROLE.ROLE_ID, MST_ROLE.ROLE_NAME"
			+ " FROM MST_WP_ACTIVITY INNER JOIN MST_ROLE ON MST_ROLE.ROLE_ID=MST_WP_ACTIVITY.ROLE_ID"
			+ " ORDER BY WP_TYPE_ID";

	@Override
	public MasterDataInfo mapRow(ResultSet resultSet, int rowNumber) throws SQLException {

		// TODO Auto-generated method stub
		Long wpTypeID = resultSet.getLong("WP_TYPE_ID");
		String activityName = resultSet.getString("ACTIVITY_NAME");
		String traloringItem = resultSet.getString("TAILORING_ITEM");
		String roleId = resultSet.getString("ROLE_ID");
		String roldeName = resultSet.getString("ROLE_NAME");

		return new MasterDataInfo(wpTypeID, activityName, traloringItem, roleId, roldeName);
	}
}