package com.conti.parma.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author uidp2090
 *
 */
@Controller
@RestController
public class HomeController {

	// @Value("${home.message}")
	// private String message;

	@RequestMapping("/")
	@GetMapping("/")
	public String welcome() {
		 
		return "PARMA HomeController!";
//		return "/home.html";
	}

	// @RequestMapping("/")
	// public String welcome(Map<String, Object> model) {
	// model.put("message", this.message);
	// return "/home";
	// }	
	
}