package com.conti.parma.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.conti.parma.model.Player;
import com.conti.parma.model.Shipwreck;
import com.conti.parma.service.SoccerService;

public class ShipwreckStub {
	private static Map<Long, Shipwreck> wrecks = new HashMap<Long, Shipwreck>();
	private static Long idIndex = 3L;
	private static Map<Long, Player> projectDetails = new HashMap<Long, Player>();
	
	@Autowired
	static
	SoccerService services;
/*
 
 	//String projectName, Integer projectId, String summary, String state
	//proejctName - /EBS/Project/Alfa_Romeo_GIORGIO_MKC1/XJ_ESC_COMFORT_AT_952
	//projectId - 30135759	
	//summary - MLC70/8_CFL_16109008_ALFA ROMEO_GIORGIO_MKC 1 ESC_ESC
	//state - planned
  
  
 * */
	//populate initial wrecks
	static {
		
		Shipwreck a = new Shipwreck(1L, "U869", "A very deep German UBoat", "FAIR", 200, 44.12, 138.44, 1994,"/EBS/Project/Alfa_Romeo_GIORGIO_MKC4",30136552," MLC70/8_ASWC_16109008_ALFA","planned");
		wrecks.put(1L, a);
		Shipwreck b = new Shipwreck(2L, "Thistlegorm", "British merchant boat in the Red Sea", "GOOD", 80, 44.12, 138.44, 1994,"/EBS/Project/Alfa_Romeo_GIORGIO_MKC1",30135759,"MLC70/8_APL_16109008_ALFA","New");
		wrecks.put(2L, b);
		Shipwreck c = new Shipwreck(3L, "S.S. Yongala", "A luxury passenger ship wrecked on the great barrier reef", "FAIR", 50, 44.12, 138.44, 1994,"/EBS/Project/Alfa_Romeo_GIORGIO_MKC2",30135765,"MLC70/8_CFL_16109008_ALFA","Realized");
		wrecks.put(3L, c);
		
		Player pl = new Player(1L,"SUZUKI",1111,"/EBS/Project/Alfa_Romeo_GIORGIO_MKC1");
		projectDetails.put(4L,pl);
//		List<String> names = services.getAllTeamPlayers(1);
//		for (String name : names) {
//			System.out.println("Project Name => " + name);
//			//projectDetails.put(1L, name )
//		}
	}

	public static List<Shipwreck> list() {
		return new ArrayList<Shipwreck>(wrecks.values());
	}

	public static List<Player> list1() {
		return new ArrayList<Player>(projectDetails.values());
	}
	
	public static Shipwreck create(Shipwreck wreck) {
		idIndex += idIndex;
		wreck.setId(idIndex);
		wrecks.put(idIndex, wreck);
		return wreck;
	}

	public static Shipwreck get(Long id) {
		return wrecks.get(id);
	}

	public static Shipwreck update(Long id, Shipwreck wreck) {
		wrecks.put(id, wreck);
		return wreck;
	}

	public static Shipwreck delete(Long id) {
		return wrecks.remove(id);
	}
	
	
}
