package com.conti.parma.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.conti.parma.dao.MasterDataDAO;
import com.conti.parma.dao.ProjectDetailsDAO;
import com.conti.parma.model.MasterDataInfo;
import com.conti.parma.model.ProjectDetailsInfo;
import com.conti.parma.model.Shipwreck;

@RestController
@RequestMapping("api/v1/")
public class AdminController {
//	@Autowired
//	SoccerService services;
	public AdminController() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping(value = "shipwrecks", method = RequestMethod.GET)
	public java.util.List<Shipwreck> List(){
		System.out.println("ShipwreckStub.list1()"+ShipwreckStub.list1().toString());
		return ShipwreckStub.list();
	}
	
//	@RequestMapping(value = "searchProjects", method = RequestMethod.GET)
//	public java.util.List<Player> List1(){
//		System.out.println("ShipwreckStub.list1()"+ShipwreckStub.list1().toString());
//		return ShipwreckStub.list1();
//	}
	
	@Autowired
    private ProjectDetailsDAO projectDetailsDAO;
	
	
//	@RequestMapping(value = "showProjects", method = RequestMethod.GET)
	
	
//	@RequestMapping(value = "shipwrecks", method = RequestMethod.GET)
//	public List<ProjectDetailsInfo> showProjects() {
//		List<ProjectDetailsInfo> list = projectDetailsDAO.getProjectDetails();
//		System.out.println("List<ProjectDetailsInfo> list: " + list.toString());
//		return list;
//	}
	
	@Autowired
	private MasterDataDAO masterDataDAO;
	@RequestMapping(value = "showMasterData", method = RequestMethod.GET)
	public List<MasterDataInfo> showMasterData() {
		List<MasterDataInfo> list = masterDataDAO.getMasterData();
		System.out.println("List<MasterDataInfo> list: " + list.toString());
		return list;
	}
	
	@RequestMapping(value = "findProject", method = RequestMethod.GET)
	public List<ProjectDetailsInfo> findProject() {
		@SuppressWarnings("unchecked")
		List<ProjectDetailsInfo> list = (List<ProjectDetailsInfo>) projectDetailsDAO.findProject((long) 16109001);
		System.out.println("List<ProjectDetailsInfo> list: " + list.toString());
		return list;
	}
}
