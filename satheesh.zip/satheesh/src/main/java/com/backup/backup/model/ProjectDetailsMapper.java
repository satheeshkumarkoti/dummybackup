package com.conti.parma.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class ProjectDetailsMapper implements RowMapper<ProjectDetailsInfo> {

	public ProjectDetailsMapper() {
		// TODO Auto-generated constructor stub 
	}
	public static final String SQL_QUERY_FOR_PROJ_DETAILS = "SELECT ID,RELEASE_NUMBER,PROJECT_NAME FROM PROJECTDETAILS ORDER BY ID";
	public static final String SQL_QUERY_FOR_MASTER_DATA = "SELECT MST_WP_ACTIVITY.WP_TYPE_ID, MST_WP_ACTIVITY.ACTIVITY_NAME, MST_WP_ACTIVITY.TAILORING_ITEM, MST_ROLE.ROLE_ID, MST_ROLE.ROLE_NAME"+
															"FROM MST_WP_ACTIVITY"+"INNER JOIN MST_ROLE ON MST_ROLE.ROLE_ID=MST_WP_ACTIVITY.ROLE_ID"+" ORDER BY WP_TYPE_ID;";
	@Override
	public ProjectDetailsInfo mapRow(ResultSet resultSet, int rowNumber) throws SQLException {
		// TODO Auto-generated method stub
		Long projectId = resultSet.getLong("ID");
        String releaseNumber = resultSet.getString("RELEASE_NUMBER");
        String projectName = resultSet.getString("PROJECT_NAME");
 
        return new ProjectDetailsInfo(projectId, releaseNumber, projectName);
	}

	
	//WP_TYPE_ID , ACTIVITY_NAME, TAILORING_ITEM, ROLE_ID, ROLE_NAME
}
