/**
 * 
 */
package com.conti.parma.service;

import java.util.List;
/**
 * @author uidp2090
 *
 */
public interface SoccerService {
	public List<String> getAllTeamPlayers(long teamId);
    public void addBarcelonaPlayer(String name, String position, int number);
    public void getMessage(String name);
}
