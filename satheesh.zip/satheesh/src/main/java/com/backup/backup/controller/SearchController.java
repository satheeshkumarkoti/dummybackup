package com.conti.parma.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.conti.parma.model.Player;

@RestController
@RequestMapping("api/search/")
public class SearchController {

	public SearchController() {
		// TODO Auto-generated constructor stub
	}
	@RequestMapping(value = "searchProjects", method = RequestMethod.GET)
	public java.util.List<Player> List1(String name){
		System.out.println("Name: "+name+" searchProjects.list1()"+ShipwreckStub.list1().toString());
		return ShipwreckStub.list1();
	}
	
//	@Autowired
//    private ProjectDetailsDAO projectDetailsDAO;
//	@RequestMapping(value = "/searchProjects", method = RequestMethod.GET)
//    public String showProjects(Model model) {
//        List<ProjectDetailsInfo> list = projectDetailsDAO.getProjectDetails();
// 
//        model.addAttribute("projectDetails", list);
// 
//        return "accountsPage";
//    }
	
}
