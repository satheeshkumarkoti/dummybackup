package com.conti.parma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParmaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParmaApplication.class, args);
		System.out.println("hello Applicarion ");
	}
}
