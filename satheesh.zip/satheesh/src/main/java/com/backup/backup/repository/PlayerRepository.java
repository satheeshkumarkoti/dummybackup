/**
 * 
 */
package com.conti.parma.repository;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.conti.parma.model.Player;

/**
 * @author uidp2090
 *
 */

@Repository
public interface PlayerRepository extends CrudRepository<Player, Long> {
	
	List<Player> findByTeamId(long teamId);

}
