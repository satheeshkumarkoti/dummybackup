/**
 * 
 */
package com.conti.parma.dao;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.conti.parma.model.MasterDataInfo;
import com.conti.parma.model.MasterDataMapper;

/**
 * @author uidp2090
 *
 */
@Repository
@Transactional
public class MasterDataDAO extends JdbcDaoSupport {

	/**
	 * 
	 */
	public MasterDataDAO() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	public MasterDataDAO(DataSource dataSource) {
		this.setDataSource(dataSource);
	}

	public List<MasterDataInfo> getMasterData() {
		String sqlQuery = MasterDataMapper.SQL_QUERY_FOR_MASTER_DATA;

		Object[] params = new Object[] {};
		MasterDataMapper masterDataMapper = new MasterDataMapper();
		List<MasterDataInfo> masterDataList = this.getJdbcTemplate().query(sqlQuery, params, masterDataMapper);

		return masterDataList;
	}
}
