package com.conti.parma.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.conti.parma.model.Player;
import com.conti.parma.model.Team;
import com.conti.parma.repository.PlayerRepository;
import com.conti.parma.repository.TeamRepository;

@Service
public class SoccerServiceImpl implements SoccerService {

	public SoccerServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Autowired
	private PlayerRepository playerRepository;
	@Autowired
	private TeamRepository teamRepository;

	public List<String> getAllTeamPlayers(long teamId) {
		List<String> result = new ArrayList<String>();
		List<Player> players = playerRepository.findByTeamId(teamId);
		for (Player player : players) {
			result.add(player.getName());
		}
		return result;
	}

	public void addBarcelonaPlayer(String name, String position, int number) {
		Team barcelona = teamRepository.findByPlayers(1);
		Player newPlayer = new Player();
		newPlayer.setName(name);
		newPlayer.setPosition(position);
		newPlayer.setNum(number);
		newPlayer.setTeam(barcelona);
		playerRepository.save(newPlayer);
	}

	@Override
	public void getMessage(String name) {
		// TODO Auto-generated method stub
		System.out.println("Name: "+name);
	}

}
